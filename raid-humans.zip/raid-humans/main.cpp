#include <SFML/Graphics.hpp>
#include "include/Mapa.h"
#include <iostream>
#include "tinyxml2.h"
#include <vector>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include "include/juego.h"
//#include <player.h>
using namespace std;
using namespace sf;
int main()
{
    juego* game = new juego(Vector2u(800,800));

}
